public class Jogo {
    // Atributos do Jogo
    private String nomeJogo;
    private String generoJogo;

    // Getters and setters
    public String getNomeJogo() {
        return nomeJogo;
    }
    public void setNomeJogo(String nomeJogo) {
        this.nomeJogo = nomeJogo;
    }
    public String getGeneroJogo() {
        return generoJogo;
    }
    public void setGeneroJogo(String generoJogo) {
        this.generoJogo = generoJogo;
    }
}